export default class Term {
  constructor(field, text) {
    this.field = field;
    this.text = text;
  }
}
