export default class Query {
  search(index) {}
}
