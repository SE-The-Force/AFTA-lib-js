export default class Parser {
  constructor(location) {
    this.location = location;
  }

  isStored(header) {}

  isIndexable(header) {}

  isAnalyzed(header) {}

  async parse() {}
}
