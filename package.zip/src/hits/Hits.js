export default class Hits {
  constructor(totalHits, documents) {
    this.totalHits = totalHits;
    this.documents = documents;
  }
}
